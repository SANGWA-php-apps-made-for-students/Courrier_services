<?php
    require_once '../web_db/connection.php';

    class multi_values {

        function list_account($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_id']; ?>
                        </td>
                        <td class="account_category_id_cols account " title="account" >
                            <?php echo $this->_e($row['account_category']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_created']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['profile']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['password']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['is_online']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id']; ?>"  data-table="account">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_account_category($id) {

                $db = new dbconnection();
                $sql = "select   account.account_category from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account_category'];
                echo $field;
            }

            function get_chosen_account_date_created($id) {

                $db = new dbconnection();
                $sql = "select   account.date_created from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_created'];
                echo $field;
            }

            function get_chosen_account_profile($id) {

                $db = new dbconnection();
                $sql = "select   account.profile from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_account_username($id) {

                $db = new dbconnection();
                $sql = "select   account.username from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['username'];
                echo $field;
            }

            function get_chosen_account_password($id) {

                $db = new dbconnection();
                $sql = "select   account.password from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['password'];
                echo $field;
            }

            function get_chosen_account_is_online($id) {

                $db = new dbconnection();
                $sql = "select   account.is_online from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['is_online'];
                echo $field;
            }

            function All_account() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_id   from account";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function get_last_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function list_account_category($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account_category </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_category_id']; ?>
                        </td>
                        <td class="name_id_cols account_category " title="account_category" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_category_id']; ?>"  data-table="account_category">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_category_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_category_id']; ?>" data-table="account_category" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_category_name($id) {

                $db = new dbconnection();
                $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_category_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_account_category() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_category_id   from account_category";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function get_last_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function list_profile($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> profile </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['profile_id']; ?>
                        </td>
                        <td class="dob_id_cols profile " title="profile" >
                            <?php echo $this->_e($row['dob']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['telephone_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['email']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['image']); ?>
                        </td>


                        <td>
                            <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id']; ?>"  data-table="profile">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_profile_dob($id) {

                $db = new dbconnection();
                $sql = "select   profile.dob from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['dob'];
                echo $field;
            }

            function get_chosen_profile_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_profile_last_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['last_name'];
                echo $field;
            }

            function get_chosen_profile_gender($id) {

                $db = new dbconnection();
                $sql = "select   profile.gender from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['gender'];
                echo $field;
            }

            function get_chosen_profile_telephone_number($id) {

                $db = new dbconnection();
                $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['telephone_number'];
                echo $field;
            }

            function get_chosen_profile_email($id) {

                $db = new dbconnection();
                $sql = "select   profile.email from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['email'];
                echo $field;
            }

            function get_chosen_profile_residence($id) {

                $db = new dbconnection();
                $sql = "select   profile.residence from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['residence'];
                echo $field;
            }

            function get_chosen_profile_image($id) {

                $db = new dbconnection();
                $sql = "select   profile.image from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['image'];
                echo $field;
            }

            function All_profile() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  profile_id   from profile";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function get_last_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function list_image($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> image </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['image_id']; ?>
                        </td>
                        <td class="path_id_cols image " title="image" >
                            <?php echo $this->_e($row['path']); ?>
                        </td>


                        <td>
                            <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['image_id']; ?>"  data-table="image">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="image_update_link" style="color: #000080;" data-id_update="<?php echo $row['image_id']; ?>" data-table="image" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_image_path($id) {

                $db = new dbconnection();
                $sql = "select   image.path from image where image_id=:image_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':image_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['path'];
                echo $field;
            }

            function All_image() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  image_id   from image";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function get_last_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function list_Trip($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Trip";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Trip </td>
                        <td> Departure </td><td> destination </td><td> Departure Time </td><td> Trip_duration </td><td> comments </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['Trip_id']; ?>
                        </td>
                        <td class="departure_id_cols Trip " title="Trip" >
                            <?php echo $this->_e($row['departure']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['destination']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['departure_time']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['trp_duration']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>


                        <td>
                            <a href="#" class="Trip_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['Trip_id']; ?>"  data-table="Trip">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="Trip_update_link" style="color: #000080;" data-id_update="<?php echo $row['Trip_id']; ?>" data-table="Trip" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_Trip_departure($id) {

                $db = new dbconnection();
                $sql = "select   Trip.departure from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['departure'];
                echo $field;
            }

            function get_chosen_Trip_destination($id) {

                $db = new dbconnection();
                $sql = "select   Trip.destination from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['destination'];
                echo $field;
            }

            function get_chosen_Trip_departure_time($id) {

                $db = new dbconnection();
                $sql = "select   Trip.departure_time from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['departure_time'];
                echo $field;
            }

            function get_chosen_Trip_trp_duration($id) {

                $db = new dbconnection();
                $sql = "select   Trip.trp_duration from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['trp_duration'];
                echo $field;
            }

            function get_chosen_Trip_comments($id) {

                $db = new dbconnection();
                $sql = "select   Trip.comments from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function All_Trip() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  Trip_id   from Trip";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_Trip() {
                $con = new dbconnection();
                $sql = "select Trip.Trip_id from Trip
                    order by Trip.Trip_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Trip_id'];
                return $first_rec;
            }

            function get_last_Trip() {
                $con = new dbconnection();
                $sql = "select Trip.Trip_id from Trip
                    order by Trip.Trip_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Trip_id'];
                return $first_rec;
            }

            function list_Customer($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Customer";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Customer </td>
                        <td> profile </td><td> National ID </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['Customer_id']; ?>
                        </td>
                        <td class="profile_id_cols Customer " title="Customer" >
                            <?php echo $this->_e($row['profile']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['national_id']); ?>
                        </td>


                        <td>
                            <a href="#" class="Customer_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['Customer_id']; ?>"  data-table="Customer">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="Customer_update_link" style="color: #000080;" data-id_update="<?php echo $row['Customer_id']; ?>" data-table="Customer" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_Customer_profile($id) {

                $db = new dbconnection();
                $sql = "select   Customer.profile from Customer where Customer_id=:Customer_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Customer_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_Customer_national_id($id) {

                $db = new dbconnection();
                $sql = "select   Customer.national_id from Customer where Customer_id=:Customer_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Customer_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['national_id'];
                echo $field;
            }

            function All_Customer() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  Customer_id   from Customer";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_Customer() {
                $con = new dbconnection();
                $sql = "select Customer.Customer_id from Customer
                    order by Customer.Customer_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Customer_id'];
                return $first_rec;
            }

            function get_last_Customer() {
                $con = new dbconnection();
                $sql = "select Customer.Customer_id from Customer
                    order by Customer.Customer_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Customer_id'];
                return $first_rec;
            }

            function list_Stops($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Stops";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Stops </td>
                        <td> Stop Name </td><td> Province </td><td> Trip </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['Stops_id']; ?>
                        </td>
                        <td class="stop_name_id_cols Stops " title="Stops" >
                            <?php echo $this->_e($row['stop_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['province']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['trip']); ?>
                        </td>


                        <td>
                            <a href="#" class="Stops_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['Stops_id']; ?>"  data-table="Stops">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="Stops_update_link" style="color: #000080;" data-id_update="<?php echo $row['Stops_id']; ?>" data-table="Stops" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_Stops_stop_name($id) {

                $db = new dbconnection();
                $sql = "select   Stops.stop_name from Stops where Stops_id=:Stops_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Stops_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['stop_name'];
                echo $field;
            }

            function get_chosen_Stops_province($id) {

                $db = new dbconnection();
                $sql = "select   Stops.province from Stops where Stops_id=:Stops_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Stops_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['province'];
                echo $field;
            }

            function get_chosen_Stops_trip($id) {

                $db = new dbconnection();
                $sql = "select   Stops.trip from Stops where Stops_id=:Stops_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Stops_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['trip'];
                echo $field;
            }

            function All_Stops() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  Stops_id   from Stops";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_Stops() {
                $con = new dbconnection();
                $sql = "select Stops.Stops_id from Stops
                    order by Stops.Stops_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Stops_id'];
                return $first_rec;
            }

            function get_last_Stops() {
                $con = new dbconnection();
                $sql = "select Stops.Stops_id from Stops
                    order by Stops.Stops_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Stops_id'];
                return $first_rec;
            }

            function list_courier($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from courier";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> courier </td>
                        <td> Name </td><td> Weight in grams </td><td> Customer </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['courier_id']; ?>
                        </td>
                        <td class="name_id_cols courier " title="courier" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['weight']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['customer']); ?>
                        </td>


                        <td>
                            <a href="#" class="courier_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_id']; ?>"  data-table="courier">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="courier_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_id']; ?>" data-table="courier" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_courier_name($id) {

                $db = new dbconnection();
                $sql = "select   courier.name from courier where courier_id=:courier_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_courier_weight($id) {

                $db = new dbconnection();
                $sql = "select   courier.weight from courier where courier_id=:courier_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['weight'];
                echo $field;
            }

            function get_chosen_courier_customer($id) {

                $db = new dbconnection();
                $sql = "select   courier.customer from courier where courier_id=:courier_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['customer'];
                echo $field;
            }

            function All_courier() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  courier_id   from courier";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_courier() {
                $con = new dbconnection();
                $sql = "select courier.courier_id from courier
                    order by courier.courier_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['courier_id'];
                return $first_rec;
            }

            function get_last_courier() {
                $con = new dbconnection();
                $sql = "select courier.courier_id from courier
                    order by courier.courier_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['courier_id'];
                return $first_rec;
            }

            function list_courier_reception($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from courier_reception";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> courier_reception </td>
                        <td> Courier </td><td> Entry Date </td><td> User </td><td> New Trip Id </td><td> Stop </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['courier_reception_id']; ?>
                        </td>
                        <td class="courier_id_cols courier_reception " title="courier_reception" >
                            <?php echo $this->_e($row['courier']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['new-trip_id']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['stop']); ?>
                        </td>


                        <td>
                            <a href="#" class="courier_reception_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_reception_id']; ?>"  data-table="courier_reception">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="courier_reception_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_reception_id']; ?>" data-table="courier_reception" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_courier_reception_courier($id) {

                $db = new dbconnection();
                $sql = "select   courier_reception.courier from courier_reception where courier_reception_id=:courier_reception_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_reception_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['courier'];
                echo $field;
            }

            function get_chosen_courier_reception_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   courier_reception.entry_date from courier_reception where courier_reception_id=:courier_reception_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_reception_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_courier_reception_User($id) {

                $db = new dbconnection();
                $sql = "select   courier_reception.User from courier_reception where courier_reception_id=:courier_reception_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_reception_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_courier_reception_new_trip_id($id) {

                $db = new dbconnection();
                $sql = "select   courier_reception.new-trip_id from courier_reception where courier_reception_id=:courier_reception_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_reception_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['new-trip_id'];
                echo $field;
            }

            function get_chosen_courier_reception_stop($id) {

                $db = new dbconnection();
                $sql = "select   courier_reception.stop from courier_reception where courier_reception_id=:courier_reception_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':courier_reception_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['stop'];
                echo $field;
            }

            function All_courier_reception() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  courier_reception_id   from courier_reception";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_courier_reception() {
                $con = new dbconnection();
                $sql = "select courier_reception.courier_reception_id from courier_reception
                    order by courier_reception.courier_reception_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['courier_reception_id'];
                return $first_rec;
            }

            function get_last_courier_reception() {
                $con = new dbconnection();
                $sql = "select courier_reception.courier_reception_id from courier_reception
                    order by courier_reception.courier_reception_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['courier_reception_id'];
                return $first_rec;
            }

            function list_new_trip($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from new_trip";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> new_trip </td>
                        <td> trip </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['new_trip_id']; ?>
                        </td>
                        <td class="trip_id_cols new_trip " title="new_trip" >
                            <?php echo $this->_e($row['trip']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="new_trip_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['new_trip_id']; ?>"  data-table="new_trip">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="new_trip_update_link" style="color: #000080;" data-id_update="<?php echo $row['new_trip_id']; ?>" data-table="new_trip" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                    <?php
            }

//chosen individual field
            function get_chosen_new_trip_trip($id) {

                $db = new dbconnection();
                $sql = "select   new_trip.trip from new_trip where new_trip_id=:new_trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':new_trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['trip'];
                echo $field;
            }

            function get_chosen_new_trip_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   new_trip.entry_date from new_trip where new_trip_id=:new_trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':new_trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_new_trip_User($id) {

                $db = new dbconnection();
                $sql = "select   new_trip.User from new_trip where new_trip_id=:new_trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':new_trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_new_trip() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  new_trip_id   from new_trip";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_new_trip() {
                $con = new dbconnection();
                $sql = "select new_trip.new_trip_id from new_trip
                    order by new_trip.new_trip_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['new_trip_id'];
                return $first_rec;
            }

            function get_last_new_trip() {
                $con = new dbconnection();
                $sql = "select new_trip.new_trip_id from new_trip
                    order by new_trip.new_trip_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['new_trip_id'];
                return $first_rec;
            }

            function get_account_category_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select account_category.account_category_id,   account_category.name from account_category";
                ?>
            <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_profile_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id,   profile.name from profile";
            ?>
            <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_image_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select image.image_id,   image.name from image";
            ?>
            <select class="textbox cbo_image"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_profile_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id,   profile.name from profile";
            ?>
            <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_trip_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select trip.trip_id,   trip.name from trip";
            ?>
            <select class="textbox cbo_trip"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['trip_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_customer_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select customer.customer_id,   customer.name from customer";
            ?>
            <select class="textbox cbo_customer"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['customer_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_courier_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select courier.courier_id,   courier.name from courier";
            ?>
            <select class="textbox cbo_courier"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['courier_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
            }

            function get_new-trip_id_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select new-trip_id.new-trip_id_id,   new-trip_id.name from new-trip_id";
            ?>
            <select class="textbox cbo_new-trip_id"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['new-trip_id_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_stop_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select stop.stop_id,   stop.name from stop";
            ?>
            <select class="textbox cbo_stop"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['stop_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_trip_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select trip.trip_id,   trip.name from trip";
            ?>
            <select class="textbox cbo_trip"><option></option>
                    <?php
                    foreach ($db->query($sql) as $row) {
                        echo "<option value=" . $row['trip_id'] . ">" . $row['name'] . " </option>";
                    }
                    ?>
            </select>
            <?php
        }

        function _e($string) {
            echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        }

    }
    