<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_account( $account_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account where account_id =:account_id");
$smt->bindValue(':account_id',$account_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
$smt->bindValue(':account_category_id',$account_category_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM profile where profile_id =:profile_id");
$smt->bindValue(':profile_id',$profile_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_image( $image_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM image where image_id =:image_id");
$smt->bindValue(':image_id',$image_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_Trip( $Trip_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM Trip where Trip_id =:Trip_id");
$smt->bindValue(':Trip_id',$Trip_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_Customer( $Customer_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM Customer where Customer_id =:Customer_id");
$smt->bindValue(':Customer_id',$Customer_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_Stops( $Stops_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM Stops where Stops_id =:Stops_id");
$smt->bindValue(':Stops_id',$Stops_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_courier( $courier_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM courier where courier_id =:courier_id");
$smt->bindValue(':courier_id',$courier_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_courier_reception( $courier_reception_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM courier_reception where courier_reception_id =:courier_reception_id");
$smt->bindValue(':courier_reception_id',$courier_reception_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_new_trip( $new_trip_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM new_trip where new_trip_id =:new_trip_id");
$smt->bindValue(':new_trip_id',$new_trip_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}

