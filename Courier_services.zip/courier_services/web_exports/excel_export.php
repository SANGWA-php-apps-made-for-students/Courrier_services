 if (filter_has_var(INPUT_POST,'account')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['account_category'].'</td>
                 <td>'.$row['date_created'].'</td>
                 <td>'.$row['profile'].'</td>
                 <td>'.$row['username'].'</td>
                 <td>'.$row['password'].'</td>
                 <td>'.$row['is_online'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=account.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'account_category')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['name'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=account_category.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'profile')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['dob'].'</td>
                 <td>'.$row['name'].'</td>
                 <td>'.$row['last_name'].'</td>
                 <td>'.$row['gender'].'</td>
                 <td>'.$row['telephone_number'].'</td>
                 <td>'.$row['email'].'</td>
                 <td>'.$row['residence'].'</td>
                 <td>'.$row['image'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=profile.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'image')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['path'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=image.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'Trip')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Trip";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Departure</td>
               <td>destination</td>
               <td>Departure Time</td>
               <td>Trip_duration</td>
               <td>comments</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['departure'].'</td>
                 <td>'.$row['destination'].'</td>
                 <td>'.$row['departure_time'].'</td>
                 <td>'.$row['trp_duration'].'</td>
                 <td>'.$row['comments'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=Trip.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'Customer')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Customer";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>profile</td>
               <td>National ID</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['profile'].'</td>
                 <td>'.$row['national_id'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=Customer.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'Stops')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Stops";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Stop Name</td>
               <td>Province</td>
               <td>Trip</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['stop_name'].'</td>
                 <td>'.$row['province'].'</td>
                 <td>'.$row['trip'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=Stops.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'courier')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from courier";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Name</td>
               <td>Weight in grams</td>
               <td>Customer</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['name'].'</td>
                 <td>'.$row['weight'].'</td>
                 <td>'.$row['customer'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=courier.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'courier_reception')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from courier_reception";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Courier</td>
               <td>Entry Date</td>
               <td>User</td>
               <td>New Trip Id</td>
               <td>Stop</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['courier'].'</td>
                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>
                 <td>'.$row['new-trip_id'].'</td>
                 <td>'.$row['stop'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=courier_reception.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'new_trip')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from new_trip";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>trip</td>
               <td>Entry Date</td>
               <td>User</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['trip'].'</td>
                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=new_trip.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

