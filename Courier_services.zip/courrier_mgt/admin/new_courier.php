<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_courier'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'courier'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $courier_id=$_SESSION['id_upd'];
                      
$name = $_POST['txt_name'];
$weight = $_POST['txt_weight'];
$customer = $_POST['txt_customer'];


$upd_obj->update_courier($name, $weight, $customer,$courier_id);
unset($_SESSION['table_to_update']);
}}else{$name = $_POST['txt_name'];
$weight = $_POST['txt_weight'];
$customer = $_POST['txt_customer'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_courier($name, $weight, $customer);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
courier</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_courier.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->


      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
          <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

<div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 courier saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  courier Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_name">name </label></td><td> <input type="text"     name="txt_name" required id="txt_name" class="textbox" value="<?php echo trim(chosen_name_upd());?>"   />  </td></tr>
<tr><td><label for="txt_weight">weight </label></td><td> <input type="text"     name="txt_weight" required id="txt_weight" class="textbox" value="<?php echo trim(chosen_weight_upd());?>"   />  </td></tr>
<tr><td><label for="txt_customer">customer </label></td><td> <input type="text"     name="txt_customer" required id="txt_customer" class="textbox" value="<?php echo trim(chosen_customer_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_courier" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">courier List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_courier();
                    $obj->list_courier($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
<script>
    var txt_update = $('#txt_shall_expand_toUpdate').val();
    if (txt_update != '') {
            }
</script>
</body>
</hmtl>
<?php
function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'courier') {               $id = $_SESSION['id_upd'];
               $name = new multi_values();
               return $name->get_chosen_courier_name($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_weight_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'courier') {               $id = $_SESSION['id_upd'];
               $weight = new multi_values();
               return $weight->get_chosen_courier_weight($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_customer_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'courier') {               $id = $_SESSION['id_upd'];
               $customer = new multi_values();
               return $customer->get_chosen_courier_customer($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}

