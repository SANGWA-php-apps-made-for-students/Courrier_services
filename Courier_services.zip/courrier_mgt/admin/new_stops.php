<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_stops'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'stops'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $stops_id=$_SESSION['id_upd'];
                      
$stop_name = $_POST['txt_stop_name'];
$province = $_POST['txt_province'];
$trip = $_POST['txt_trip'];


$upd_obj->update_stops($stop_name, $province, $trip,$stops_id);
unset($_SESSION['table_to_update']);
}}else{$stop_name = $_POST['txt_stop_name'];
$province = $_POST['txt_province'];
$trip = $_POST['txt_trip'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_stops($stop_name, $province, $trip);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
stops</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_stops.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->


      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
          <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

<div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 stops saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  stops Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_stop_name">stop_name </label></td><td> <input type="text"     name="txt_stop_name" required id="txt_stop_name" class="textbox" value="<?php echo trim(chosen_stop_name_upd());?>"   />  </td></tr>
<tr><td><label for="txt_province">province </label></td><td> <input type="text"     name="txt_province" required id="txt_province" class="textbox" value="<?php echo trim(chosen_province_upd());?>"   />  </td></tr>
<tr><td><label for="txt_trip">trip </label></td><td> <input type="text"     name="txt_trip" required id="txt_trip" class="textbox" value="<?php echo trim(chosen_trip_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_stops" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">stops List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_stops();
                    $obj->list_stops($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
<script>
    var txt_update = $('#txt_shall_expand_toUpdate').val();
    if (txt_update != '') {
            }
</script>
</body>
</hmtl>
<?php
function chosen_stop_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'stops') {               $id = $_SESSION['id_upd'];
               $stop_name = new multi_values();
               return $stop_name->get_chosen_stops_stop_name($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_province_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'stops') {               $id = $_SESSION['id_upd'];
               $province = new multi_values();
               return $province->get_chosen_stops_province($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_trip_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'stops') {               $id = $_SESSION['id_upd'];
               $trip = new multi_values();
               return $trip->get_chosen_stops_trip($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}

