
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11)   
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11)   
,`name`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `courier`
--

CREATE TABLE IF NOT EXISTS `courier` (
`courier_id`     int(11)   
,`name`     VARCHAR(60) 
,`weight`     VARCHAR(60) 
, `customer`     int(11)   
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `courier_reception`
--

CREATE TABLE IF NOT EXISTS `courier_reception` (
`courier_reception_id`     int(11)   
, `courier`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `new-trip_id`     int(11)   
, `stop`     int(11)   
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`Customer_id`     int(11)   
, `profile`     int(11)   
,`national_id`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11)   
,`path`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `new_trip`
--

CREATE TABLE IF NOT EXISTS `new_trip` (
`new_trip_id`     int(11)   
, `trip`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11)   
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `stops`
--

CREATE TABLE IF NOT EXISTS `stops` (
`Stops_id`     int(11)   
,`stop_name`     VARCHAR(60) 
,`province`     VARCHAR(60) 
, `trip`     int(11)   
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `trip`
--

CREATE TABLE IF NOT EXISTS `trip` (
`Trip_id`     int(11)   
,`departure`     VARCHAR(60) 
,`destination`     VARCHAR(60) 
,`departure_time`     VARCHAR(60) 
,`trp_duration`     VARCHAR(60) 
,`comments`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

