<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_courier( $name, $weight, $customer,$courier_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE courier set 
name= ?, weight= ?, customer= ? WHERE courier_id=?");
$stmt->execute(array($name, $weight, $customer ,$courier_id ));

}
 function update_courier_reception( $courier, $entry_date, $User, $new-trip_id, $stop,$courier_reception_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE courier_reception set 
courier= ?, entry_date= ?, User= ?, new-trip_id= ?, stop= ? WHERE courier_reception_id=?");
$stmt->execute(array($courier, $entry_date, $User, $new-trip_id, $stop ,$courier_reception_id ));

}
 function update_customer( $profile, $national_id,$customer_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE customer set 
profile= ?, national_id= ? WHERE customer_id=?");
$stmt->execute(array($profile, $national_id ,$customer_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_new_trip( $trip, $entry_date, $User,$new_trip_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE new_trip set 
trip= ?, entry_date= ?, User= ? WHERE new_trip_id=?");
$stmt->execute(array($trip, $entry_date, $User ,$new_trip_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_stops( $stop_name, $province, $trip,$stops_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE stops set 
stop_name= ?, province= ?, trip= ? WHERE stops_id=?");
$stmt->execute(array($stop_name, $province, $trip ,$stops_id ));

}
 function update_trip( $departure, $destination, $departure_time, $trp_duration, $comments,$trip_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE trip set 
departure= ?, destination= ?, departure_time= ?, trp_duration= ?, comments= ? WHERE trip_id=?");
$stmt->execute(array($departure, $destination, $departure_time, $trp_duration, $comments ,$trip_id ));

}

}

