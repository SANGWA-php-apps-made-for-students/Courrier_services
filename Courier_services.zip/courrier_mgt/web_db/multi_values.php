<?php
 require_once '../web_db/connection.php'; 
class multi_values{


function list_account($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account </td>
<td> account_category </td><td> date_created </td><td> profile </td><td> username </td><td> password </td><td> is_online </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td class="account_category_id_cols account " title="account" >
<?php echo  $this->_e($row['account_category']); ?>
</td>
<td>
<?php echo  $this->_e($row['date_created']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['username']); ?>
</td>
<td>
<?php echo  $this->_e($row['password']); ?>
</td>
<td>
<?php echo  $this->_e($row['is_online']); ?>
</td>


<td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id'];?>"  data-table="account">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_account_category($id) {
        
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    } function get_chosen_account_date_created($id) {
        
        $db = new dbconnection();
        $sql = "select   account.date_created from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_created'];
        echo $field;
    } function get_chosen_account_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_account_username($id) {
        
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    } function get_chosen_account_password($id) {
        
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    } function get_chosen_account_is_online($id) {
        
        $db = new dbconnection();
        $sql = "select   account.is_online from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['is_online'];
        echo $field;
    }

 function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
 function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
function list_account_category($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account_category";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account_category </td>
<td> name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_category_id']; ?>
</td>
<td class="name_id_cols account_category " title="account_category" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_category_id'];?>"  data-table="account_category">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_category_id']; ?>" data-table="account_category" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_category_name($id) {
        
        $db = new dbconnection();
        $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_account_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_category_id   from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
 function get_last_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
function list_courier($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from courier";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> courier </td>
<td> name </td><td> weight </td><td> customer </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['courier_id']; ?>
</td>
<td class="name_id_cols courier " title="courier" >
<?php echo  $this->_e($row['name']); ?>
</td>
<td>
<?php echo  $this->_e($row['weight']); ?>
</td>
<td>
<?php echo  $this->_e($row['customer']); ?>
</td>


<td>
                        <a href="#" class="courier_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_id'];?>"  data-table="courier">Delete</a>
                    </td>
<td>
                        <a href="#" class="courier_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_id']; ?>" data-table="courier" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_courier_name($id) {
        
        $db = new dbconnection();
        $sql = "select   courier.name from courier where courier_id=:courier_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    } function get_chosen_courier_weight($id) {
        
        $db = new dbconnection();
        $sql = "select   courier.weight from courier where courier_id=:courier_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['weight'];
        echo $field;
    } function get_chosen_courier_customer($id) {
        
        $db = new dbconnection();
        $sql = "select   courier.customer from courier where courier_id=:courier_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['customer'];
        echo $field;
    }

 function All_courier() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  courier_id   from courier";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_courier() {
        $con = new dbconnection();
        $sql = "select courier.courier_id from courier
                    order by courier.courier_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['courier_id'];
        return $first_rec;
    }
 function get_last_courier() {
        $con = new dbconnection();
        $sql = "select courier.courier_id from courier
                    order by courier.courier_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['courier_id'];
        return $first_rec;
    }
function list_courier_reception($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from courier_reception";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> courier_reception </td>
<td> courier </td><td> entry_date </td><td> User </td><td> new-trip_id </td><td> stop </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['courier_reception_id']; ?>
</td>
<td class="courier_id_cols courier_reception " title="courier_reception" >
<?php echo  $this->_e($row['courier']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['new-trip_id']); ?>
</td>
<td>
<?php echo  $this->_e($row['stop']); ?>
</td>


<td>
                        <a href="#" class="courier_reception_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_reception_id'];?>"  data-table="courier_reception">Delete</a>
                    </td>
<td>
                        <a href="#" class="courier_reception_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_reception_id']; ?>" data-table="courier_reception" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_courier_reception_courier($id) {
        
        $db = new dbconnection();
        $sql = "select   courier_reception.courier from courier_reception where courier_reception_id=:courier_reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['courier'];
        echo $field;
    } function get_chosen_courier_reception_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   courier_reception.entry_date from courier_reception where courier_reception_id=:courier_reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_courier_reception_User($id) {
        
        $db = new dbconnection();
        $sql = "select   courier_reception.User from courier_reception where courier_reception_id=:courier_reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_courier_reception_new-trip_id($id) {
        
        $db = new dbconnection();
        $sql = "select   courier_reception.new-trip_id from courier_reception where courier_reception_id=:courier_reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['new-trip_id'];
        echo $field;
    } function get_chosen_courier_reception_stop($id) {
        
        $db = new dbconnection();
        $sql = "select   courier_reception.stop from courier_reception where courier_reception_id=:courier_reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':courier_reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['stop'];
        echo $field;
    }

 function All_courier_reception() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  courier_reception_id   from courier_reception";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_courier_reception() {
        $con = new dbconnection();
        $sql = "select courier_reception.courier_reception_id from courier_reception
                    order by courier_reception.courier_reception_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['courier_reception_id'];
        return $first_rec;
    }
 function get_last_courier_reception() {
        $con = new dbconnection();
        $sql = "select courier_reception.courier_reception_id from courier_reception
                    order by courier_reception.courier_reception_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['courier_reception_id'];
        return $first_rec;
    }
function list_customer($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from customer";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> customer </td>
<td> profile </td><td> national_id </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['customer_id']; ?>
</td>
<td class="profile_id_cols customer " title="customer" >
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['national_id']); ?>
</td>


<td>
                        <a href="#" class="customer_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['customer_id'];?>"  data-table="customer">Delete</a>
                    </td>
<td>
                        <a href="#" class="customer_update_link" style="color: #000080;" data-id_update="<?php echo $row['customer_id']; ?>" data-table="customer" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_customer_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   customer.profile from customer where customer_id=:customer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':customer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_customer_national_id($id) {
        
        $db = new dbconnection();
        $sql = "select   customer.national_id from customer where customer_id=:customer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':customer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['national_id'];
        echo $field;
    }

 function All_customer() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  customer_id   from customer";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_customer() {
        $con = new dbconnection();
        $sql = "select customer.customer_id from customer
                    order by customer.customer_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['customer_id'];
        return $first_rec;
    }
 function get_last_customer() {
        $con = new dbconnection();
        $sql = "select customer.customer_id from customer
                    order by customer.customer_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['customer_id'];
        return $first_rec;
    }
function list_image($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from image";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> image </td>
<td> path </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['image_id']; ?>
</td>
<td class="path_id_cols image " title="image" >
<?php echo  $this->_e($row['path']); ?>
</td>


<td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['image_id'];?>"  data-table="image">Delete</a>
                    </td>
<td>
                        <a href="#" class="image_update_link" style="color: #000080;" data-id_update="<?php echo $row['image_id']; ?>" data-table="image" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_image_path($id) {
        
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['path'];
        echo $field;
    }

 function All_image() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  image_id   from image";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
 function get_last_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
function list_new_trip($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from new_trip";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> new_trip </td>
<td> trip </td><td> entry_date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['new_trip_id']; ?>
</td>
<td class="trip_id_cols new_trip " title="new_trip" >
<?php echo  $this->_e($row['trip']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>


<td>
                        <a href="#" class="new_trip_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['new_trip_id'];?>"  data-table="new_trip">Delete</a>
                    </td>
<td>
                        <a href="#" class="new_trip_update_link" style="color: #000080;" data-id_update="<?php echo $row['new_trip_id']; ?>" data-table="new_trip" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_new_trip_trip($id) {
        
        $db = new dbconnection();
        $sql = "select   new_trip.trip from new_trip where new_trip_id=:new_trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':new_trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['trip'];
        echo $field;
    } function get_chosen_new_trip_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   new_trip.entry_date from new_trip where new_trip_id=:new_trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':new_trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_new_trip_User($id) {
        
        $db = new dbconnection();
        $sql = "select   new_trip.User from new_trip where new_trip_id=:new_trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':new_trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

 function All_new_trip() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  new_trip_id   from new_trip";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_new_trip() {
        $con = new dbconnection();
        $sql = "select new_trip.new_trip_id from new_trip
                    order by new_trip.new_trip_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['new_trip_id'];
        return $first_rec;
    }
 function get_last_new_trip() {
        $con = new dbconnection();
        $sql = "select new_trip.new_trip_id from new_trip
                    order by new_trip.new_trip_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['new_trip_id'];
        return $first_rec;
    }
function list_profile($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from profile";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> profile </td>
<td> dob </td><td> name </td><td> last_name </td><td> gender </td><td> telephone_number </td><td> email </td><td> residence </td><td> image </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['profile_id']; ?>
</td>
<td class="dob_id_cols profile " title="profile" >
<?php echo  $this->_e($row['dob']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>
<td>
<?php echo  $this->_e($row['last_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['gender']); ?>
</td>
<td>
<?php echo  $this->_e($row['telephone_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['email']); ?>
</td>
<td>
<?php echo  $this->_e($row['residence']); ?>
</td>
<td>
<?php echo  $this->_e($row['image']); ?>
</td>


<td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id'];?>"  data-table="profile">Delete</a>
                    </td>
<td>
                        <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_profile_dob($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    } function get_chosen_profile_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    } function get_chosen_profile_last_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    } function get_chosen_profile_gender($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    } function get_chosen_profile_telephone_number($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['telephone_number'];
        echo $field;
    } function get_chosen_profile_email($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    } function get_chosen_profile_residence($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    } function get_chosen_profile_image($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

 function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
 function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
function list_stops($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from stops";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> stops </td>
<td> stop_name </td><td> province </td><td> trip </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['stops_id']; ?>
</td>
<td class="stop_name_id_cols stops " title="stops" >
<?php echo  $this->_e($row['stop_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['province']); ?>
</td>
<td>
<?php echo  $this->_e($row['trip']); ?>
</td>


<td>
                        <a href="#" class="stops_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['stops_id'];?>"  data-table="stops">Delete</a>
                    </td>
<td>
                        <a href="#" class="stops_update_link" style="color: #000080;" data-id_update="<?php echo $row['stops_id']; ?>" data-table="stops" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_stops_stop_name($id) {
        
        $db = new dbconnection();
        $sql = "select   stops.stop_name from stops where stops_id=:stops_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':stops_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['stop_name'];
        echo $field;
    } function get_chosen_stops_province($id) {
        
        $db = new dbconnection();
        $sql = "select   stops.province from stops where stops_id=:stops_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':stops_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['province'];
        echo $field;
    } function get_chosen_stops_trip($id) {
        
        $db = new dbconnection();
        $sql = "select   stops.trip from stops where stops_id=:stops_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':stops_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['trip'];
        echo $field;
    }

 function All_stops() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  stops_id   from stops";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_stops() {
        $con = new dbconnection();
        $sql = "select stops.stops_id from stops
                    order by stops.stops_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['stops_id'];
        return $first_rec;
    }
 function get_last_stops() {
        $con = new dbconnection();
        $sql = "select stops.stops_id from stops
                    order by stops.stops_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['stops_id'];
        return $first_rec;
    }
function list_trip($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from trip";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> trip </td>
<td> departure </td><td> destination </td><td> departure_time </td><td> trp_duration </td><td> comments </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['trip_id']; ?>
</td>
<td class="departure_id_cols trip " title="trip" >
<?php echo  $this->_e($row['departure']); ?>
</td>
<td>
<?php echo  $this->_e($row['destination']); ?>
</td>
<td>
<?php echo  $this->_e($row['departure_time']); ?>
</td>
<td>
<?php echo  $this->_e($row['trp_duration']); ?>
</td>
<td>
<?php echo  $this->_e($row['comments']); ?>
</td>


<td>
                        <a href="#" class="trip_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['trip_id'];?>"  data-table="trip">Delete</a>
                    </td>
<td>
                        <a href="#" class="trip_update_link" style="color: #000080;" data-id_update="<?php echo $row['trip_id']; ?>" data-table="trip" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_trip_departure($id) {
        
        $db = new dbconnection();
        $sql = "select   trip.departure from trip where trip_id=:trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['departure'];
        echo $field;
    } function get_chosen_trip_destination($id) {
        
        $db = new dbconnection();
        $sql = "select   trip.destination from trip where trip_id=:trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['destination'];
        echo $field;
    } function get_chosen_trip_departure_time($id) {
        
        $db = new dbconnection();
        $sql = "select   trip.departure_time from trip where trip_id=:trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['departure_time'];
        echo $field;
    } function get_chosen_trip_trp_duration($id) {
        
        $db = new dbconnection();
        $sql = "select   trip.trp_duration from trip where trip_id=:trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['trp_duration'];
        echo $field;
    } function get_chosen_trip_comments($id) {
        
        $db = new dbconnection();
        $sql = "select   trip.comments from trip where trip_id=:trip_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':trip_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comments'];
        echo $field;
    }

 function All_trip() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  trip_id   from trip";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_trip() {
        $con = new dbconnection();
        $sql = "select trip.trip_id from trip
                    order by trip.trip_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['trip_id'];
        return $first_rec;
    }
 function get_last_trip() {
        $con = new dbconnection();
        $sql = "select trip.trip_id from trip
                    order by trip.trip_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['trip_id'];
        return $first_rec;
    }

 function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

