<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                gg
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_courier.php">courier</a>
<a href="new_courier_reception.php">courier_reception</a>
<a href="new_customer.php">customer</a>
<a href="new_image.php">image</a>
<a href="new_new_trip.php">new_trip</a>
<a href="new_profile.php">profile</a>
<a href="new_stops.php">stops</a>
<a href="new_trip.php">trip</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
