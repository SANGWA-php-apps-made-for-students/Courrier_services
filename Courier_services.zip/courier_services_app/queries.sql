SELECT * FROM test.user;

delete from customer;

select * from trip;

 

 



-- here is to get the stops by the trip
select count(stops.Stops_id) from courier_reception
join courier  on courier_reception.courier = courier.courier_id 
join customer on customer.Customer_id=courier.customer
join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
join trip on trip.Trip_id=new_trip.trip
join stops on stops.trip=trip.Trip_id  
 where trip.Trip_id='' and customer.Customer_id=17;





--  Here is to ge the reception of the package in total
select count(courier_reception.courier_reception_id) from courier_reception
join courier  on courier_reception.courier = courier.courier_id 
join customer on customer.Customer_id=courier.customer
join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
join trip on trip.Trip_id=new_trip.trip
where trip.Trip_id='on' and customer.Customer_id=17;



-- the current trip of the customer
select count(new_trip.new_trip_id) from courier_reception
join courier  on courier_reception.courier = courier.courier_id 
join customer on customer.Customer_id=courier.customer
join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
 

where new_trip.status='on' and customer.Customer_id=17;


 