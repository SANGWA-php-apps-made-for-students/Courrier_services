var ref_no_found = 0;
var reference_no = 0;

var res = '';
var x = false;

var timer1;
var x_val = false;
var t;


$(document).ready(function () {
    get_random_ref();
    get_reference();
});

function get_current_page() {
    var path = window.location.pathname;
    var sp = path.split('/');
    return sp[3];
}

function no_more_counts() {
    clearTimeout(t);
}
function get_reference() {
    t = setTimeout(function () {
        if (x == true) {
            console.log('Finally: ' +Math.round( ref_no_found));
            clearTimeout(timer1);

            no_more_counts();
        } else {
            console.log('This is free: ' +Math.round( ref_no_found));
        }
        get_reference();
    }, 1000);

}

function get_random_ref() {
    if (get_current_page().trim() == 'new_courier_reception.php') {
        if (reference_no < 1000) {
            $.post('../admin/handler.php', {ref_no_found: ref_no_found}, function (data) {
                if (data != '') {
                    x = true;
                    res = data;
                    console.log('Timer 1 found:  ' + data);
                    $('#txt_reference_no').val(ref_no_found);
                } else {
                    x = true;
                    $('#txt_reference_no').val(Math.round(ref_no_found));
                    console.log('Timer 1 not found:  ' + ref_no_found);
                }
                console.log(data);
            }).complete(function () {
                if (res != '') {
                    x = true;
                }
            });

            ref_no_found = Math.random() * 10000000;
        }
        console.log('Timer 1 key response:' + res);

        timer1 = setTimeout(get_random_ref, 1000);

    } else {
        console.log('Not reception');
    }

}
