$(document).ready(function (){
   $('#date').datepicker({dateFormat:'yy-mm-dd'});
});