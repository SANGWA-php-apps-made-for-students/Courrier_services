
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Trip`
--

CREATE TABLE IF NOT EXISTS `Trip` (
`Trip_id`     int(11) NOT NULL AUTO_INCREMENT 
,`departure`     VARCHAR(60) 
,`destination`     VARCHAR(60) 
,`departure_time`     VARCHAR(60) 
,`trp_duration`     VARCHAR(60) 
,`comments`     VARCHAR(60) 

,PRIMARY KEY (`Trip_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Customer`
--

CREATE TABLE IF NOT EXISTS `Customer` (
`Customer_id`     int(11) NOT NULL AUTO_INCREMENT 
, `profile`     int(11)   

,PRIMARY KEY (`Customer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Stops`
--

CREATE TABLE IF NOT EXISTS `Stops` (
`Stops_id`     int(11) NOT NULL AUTO_INCREMENT 
,`stop_name`     VARCHAR(60) 
,`province`     VARCHAR(60) 
, `trip`     int(11)   

,PRIMARY KEY (`Stops_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `courier`
--

CREATE TABLE IF NOT EXISTS `courier` (
`courier_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`weight`     VARCHAR(60) 
, `customer`     int(11)   

,PRIMARY KEY (`courier_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Trip`
--

CREATE TABLE IF NOT EXISTS `Trip` (
`Trip_id`     int(11) NOT NULL AUTO_INCREMENT 
,`departure`     VARCHAR(60) 
,`destination`     VARCHAR(60) 
,`departure_time`     VARCHAR(60) 
,`trp_duration`     VARCHAR(60) 
,`comments`     VARCHAR(60) 

,PRIMARY KEY (`Trip_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Customer`
--

CREATE TABLE IF NOT EXISTS `Customer` (
`Customer_id`     int(11) NOT NULL AUTO_INCREMENT 
, `profile`     int(11)   

,PRIMARY KEY (`Customer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Stops`
--

CREATE TABLE IF NOT EXISTS `Stops` (
`Stops_id`     int(11) NOT NULL AUTO_INCREMENT 
,`stop_name`     VARCHAR(60) 
,`province`     VARCHAR(60) 
, `trip`     int(11)   

,PRIMARY KEY (`Stops_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `courier`
--

CREATE TABLE IF NOT EXISTS `courier` (
`courier_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`weight`     VARCHAR(60) 
, `customer`     int(11)   

,PRIMARY KEY (`courier_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `courier_reception`
--

CREATE TABLE IF NOT EXISTS `courier_reception` (
`courier_reception_id`     int(11) NOT NULL AUTO_INCREMENT 
, `courier`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`courier_reception_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

