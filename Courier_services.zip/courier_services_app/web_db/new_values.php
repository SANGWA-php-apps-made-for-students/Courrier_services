<?php

    class new_values {

        function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
                $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account_category($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
                $stm->execute(array(':account_category_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
                $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_image($path) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into image values(:image_id, :path)");
                $stm->execute(array(':image_id' => 0, ':path' => $path
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_Trip($departure, $destination, $departure_time, $trp_duration, $comments) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into Trip values(:Trip_id, :departure,  :destination,  :departure_time,  :trp_duration,  :comments)");
                $stm->execute(array(':Trip_id' => 0, ':departure' => $departure, ':destination' => $destination, ':departure_time' => $departure_time, ':trp_duration' => $trp_duration, ':comments' => $comments
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_Customer($profile, $national_id) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into customer values(:customer_id, :profile,  :national_id)");
                $stm->execute(array(':customer_id' => 0, ':profile' => $profile, ':national_id' => $national_id
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_Stops($stop_name, $province, $trip) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into Stops values(:Stops_id, :stop_name,  :province,  :trip)");
                $stm->execute(array(':Stops_id' => 0, ':stop_name' => $stop_name, ':province' => $province, ':trip' => $trip
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_courier($name, $weight, $customer) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into courier values(:courier_id, :name,  :weight,  :customer)");
                $stm->execute(array(':courier_id' => 0, ':name' => $name, ':weight' => $weight, ':customer' => $customer
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_courier_reception($courier, $entry_date, $User, $new_trip_id, $stop) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into courier_reception values(:courier_reception_id, :courier,  :entry_date,  :User,  :new_trip_id,  :stop)");
                $stm->execute(array(':courier_reception_id' => 0, ':courier' => $courier, ':entry_date' => $entry_date, ':User' => $User, ':new_trip_id' => $new_trip_id, ':stop' => $stop));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_new_trip($trip, $entry_date, $User, $status, $ref) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into new_trip values(:new_trip_id, :trip,  :entry_date,  :User,  :status, :reference_number)");
                $stm->execute(array(':new_trip_id' => 0, ':trip' => $trip, ':entry_date' => $entry_date, ':User' => $User, ':status' => $status, ':reference_number' => $ref));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e->getMessage();
            }
        }

    }
    