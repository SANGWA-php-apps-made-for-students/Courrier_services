<?php
    require_once '../web_db/connection.php';

    class multi_values {

        function list_account($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account.account_id,  account.account_category,  account.date_created,  account.profile,  account.username,  account.password,"
                    . "account_category.name as cat,"
                    . " profile.profile_id,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence from account "
                    . " join account_category on account.account_category=account_category.account_category_id "
                    . " join profile on profile.profile_id=account.profile  "
                    . " where account_category.name <>'admin'";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> account_category </td>
                        <td> Date created </td>
                        <td> Names </td>  
                        <td> Username </td>  
                        <td>Delete</td><td>Update</td></tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 


                        <td class="account_category_id_cols account " title="account" >
                            <?php echo $this->_e($row['cat']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_created']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>

                        <td>
                            <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id']; ?>"  data-table="profile">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_account_category($id) {

                $db = new dbconnection();
                $sql = "select   account.account_category from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account_category'];
                echo $field;
            }

            function get_chosen_account_date_created($id) {

                $db = new dbconnection();
                $sql = "select   account.date_created from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_created'];
                echo $field;
            }

            function get_chosen_account_profile($id) {

                $db = new dbconnection();
                $sql = "select   account.profile from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_account_username($id) {

                $db = new dbconnection();
                $sql = "select   account.username from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['username'];
                echo $field;
            }

            function get_chosen_account_password($id) {

                $db = new dbconnection();
                $sql = "select   account.password from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['password'];
                echo $field;
            }

            function get_chosen_account_is_online($id) {

                $db = new dbconnection();
                $sql = "select   account.is_online from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['is_online'];
                echo $field;
            }

            function All_account() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_id   from account";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function get_last_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function list_account_category($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account_category </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_category_id']; ?>
                        </td>
                        <td class="name_id_cols account_category " title="account_category" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                               <?php echo $row['account_category_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_category_update_link" style="color: #000080;" value="
                               <?php echo $row['account_category_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_category_name($id) {

                $db = new dbconnection();
                $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_category_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_account_category() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_category_id   from account_category";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function get_last_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function list_profile($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> profile </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['profile_id']; ?>
                        </td>
                        <td class="dob_id_cols profile " title="profile" >
                            <?php echo $this->_e($row['dob']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['telephone_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['email']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['image']); ?>
                        </td>


                        <td>
                            <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                               <?php echo $row['profile_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="profile_update_link" style="color: #000080;" value="
                               <?php echo $row['profile_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_profile_dob($id) {

                $db = new dbconnection();
                $sql = "select   profile.dob from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['dob'];
                echo $field;
            }

            function get_chosen_profile_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_profile_last_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['last_name'];
                echo $field;
            }

            function get_chosen_profile_gender($id) {

                $db = new dbconnection();
                $sql = "select   profile.gender from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['gender'];
                echo $field;
            }

            function get_chosen_profile_telephone_number($id) {

                $db = new dbconnection();
                $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['telephone_number'];
                echo $field;
            }

            function get_chosen_profile_email($id) {

                $db = new dbconnection();
                $sql = "select   profile.email from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['email'];
                echo $field;
            }

            function get_chosen_profile_residence($id) {

                $db = new dbconnection();
                $sql = "select   profile.residence from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['residence'];
                echo $field;
            }

            function get_chosen_profile_image($id) {

                $db = new dbconnection();
                $sql = "select   profile.image from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['image'];
                echo $field;
            }

            function All_profile() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  profile_id   from profile";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function get_last_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function list_image($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> image </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['image_id']; ?>
                        </td>
                        <td class="path_id_cols image " title="image" >
                            <?php echo $this->_e($row['path']); ?>
                        </td>


                        <td>
                            <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                               <?php echo $row['image_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="image_update_link" style="color: #000080;" value="
                               <?php echo $row['image_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_image_path($id) {

                $db = new dbconnection();
                $sql = "select   image.path from image where image_id=:image_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':image_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['path'];
                echo $field;
            }

            function All_image() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  image_id   from image";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function get_last_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function list_Trip($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Trip";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Trip </td>
                        <td> Line </td> <td> Departure Time </td><td> Trip_duration </td><td> comments </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['Trip_id']; ?>
                        </td>
                        <td class="departure_id_cols Trip " title="Trip" >
                            <?php echo $this->_e($row['departure'] . ' => ' . $row['destination']); ?>
                        </td>

                        <td>
                            <?php echo $this->_e($row['departure_time']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['trp_duration']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>

                        <td>
                            <a href="#" class="Trip_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['Trip_id']; ?>"  data-table="Trip">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="Trip_update_link" style="color: #000080;" data-id_update="<?php echo $row['Trip_id']; ?>" data-table="Trip" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_Trip_departure($id) {

                $db = new dbconnection();
                $sql = "select   Trip.departure from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['departure'];
                echo $field;
            }

            function get_chosen_Trip_destination($id) {

                $db = new dbconnection();
                $sql = "select   Trip.destination from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['destination'];
                echo $field;
            }

            function get_chosen_Trip_departure_time($id) {

                $db = new dbconnection();
                $sql = "select   Trip.departure_time from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['departure_time'];
                echo $field;
            }

            function get_chosen_Trip_trp_duration($id) {

                $db = new dbconnection();
                $sql = "select   Trip.trp_duration from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['trp_duration'];
                echo $field;
            }

            function get_chosen_Trip_comments($id) {

                $db = new dbconnection();
                $sql = "select   Trip.comments from Trip where Trip_id=:Trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function All_Trip() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  Trip_id   from Trip";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_Trip() {
                $con = new dbconnection();
                $sql = "select Trip.Trip_id from Trip
                    order by Trip.Trip_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Trip_id'];
                return $first_rec;
            }

            function get_last_Trip() {
                $con = new dbconnection();
                $sql = "select Trip.Trip_id from Trip
                    order by Trip.Trip_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Trip_id'];
                return $first_rec;
            }

            function list_Customer($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Customer";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> Customer </td>
                        <td> profile </td><td> National ID </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['Customer_id']; ?>
                        </td>
                        <td class="profile_id_cols Customer " title="Customer" >
                            <?php echo $this->_e($row['profile']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['national_id']); ?>
                        </td>


                        <td>
                            <a href="#" class="Customer_delete_link" style="color: #000080;" data-id_delete="Customer_id"  data-table="
                               <?php echo $row['Customer_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="Customer_update_link" style="color: #000080;" value="
                               <?php echo $row['Customer_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_Customer_profile($id) {

                $db = new dbconnection();
                $sql = "select   Customer.profile from Customer where Customer_id=:Customer_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Customer_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_Customer_national_id($id) {

                $db = new dbconnection();
                $sql = "select   Customer.national_id from Customer where Customer_id=:Customer_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Customer_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['national_id'];
                echo $field;
            }

            function All_Customer() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  Customer_id   from Customer";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_Customer() {
                $con = new dbconnection();
                $sql = "select Customer.Customer_id from Customer
                    order by Customer.Customer_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Customer_id'];
                return $first_rec;
            }

            function get_last_Customer() {
                $con = new dbconnection();
                $sql = "select Customer.Customer_id from Customer
                    order by Customer.Customer_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Customer_id'];
                return $first_rec;
            }

            function list_Stops($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from Stops   "
                        . " join trip on trip.trip_id=stops.trip";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> Stop Name </td><td> Province </td><td> Line </td>
                        <td>Delete</td><td>Update</td></tr>
                </thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 
                        <td class="stop_name_id_cols Stops " title="Stops" >
                            <?php echo $this->_e($row['stop_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['province']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['departure'] . ' => ' . $row['destination']); ?>
                        </td>
                        <td>
                            <a href="#" class="Stops_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['Stops_id']; ?>"  data-table="Stops">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="Stops_update_link" style="color: #000080;" data-id_update="<?php echo $row['Stops_id']; ?>" data-table="Stops" >Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_Stops_stop_name($id) {

                $db = new dbconnection();
                $sql = "select   Stops.stop_name from Stops where Stops_id=:Stops_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Stops_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['stop_name'];
                echo $field;
            }

            function get_chosen_Stops_province($id) {

                $db = new dbconnection();
                $sql = "select   Stops.province from Stops where Stops_id=:Stops_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Stops_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['province'];
                echo $field;
            }

            function get_chosen_Stops_trip($id) {

                $db = new dbconnection();
                $sql = "select   Stops.trip from Stops where Stops_id=:Stops_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':Stops_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['trip'];
                echo $field;
            }

            function All_Stops() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  Stops_id   from Stops";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_Stops() {
                $con = new dbconnection();
                $sql = "select Stops.Stops_id from Stops
                    order by Stops.Stops_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Stops_id'];
                return $first_rec;
            }

            function get_last_Stops() {
                $con = new dbconnection();
                $sql = "select Stops.Stops_id from Stops
                    order by Stops.Stops_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['Stops_id'];
                return $first_rec;
            }

            function list_courier($min) {
                ?>

            <table class="dataList_table">
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>package</td>
                        <td>Customer names</td>
                        <td>Stop</td>
                        <td>Option</td>
                        <td>Option</td>
                    </tr>
                </thead>
                <?php
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "select profile.name,  profile.last_name,"
                        . " courier.name as courier,  courier.weight, "
                        . " trip.departure, trip.destination, "
                        . " courier.courier_id ,courier.name as courier, "
                        . " stops.stop_name as stop"
                        . " from courier "
                        . " join courier_reception  on courier_reception.courier = courier.courier_id "
                        . " join customer on customer.Customer_id=courier.customer "
                        . " join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                            join trip on trip.Trip_id=new_trip.trip 
                             join stops on stops.trip=trip.trip_id"
                        . " join profile on profile.profile_id=customer.profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?>
                    <tr> 

                        <td>
                            <?php echo $row['courier_id']; ?>
                        </td>
                        <td class="name_id_cols courier " title="courier" >
                            <?php echo $this->_e($row['courier'] . ', ' . $row['weight'] . ' grams'); ?>
                        </td>

                        <td>
                            <?php echo $this->_e($row['name'] . '  ' . $row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['stop']); ?>
                        </td>


                        <td>
                            <a href="#" class="courier_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_id']; ?>"  data-table="courier">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="courier_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_id']; ?>"  data-table="courier">Update</a>
                        </td>
                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_courier_name($id) {

            $db = new dbconnection();
            $sql = "select   courier.name from courier where courier_id=:courier_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_courier_weight($id) {

            $db = new dbconnection();
            $sql = "select   courier.weight from courier where courier_id=:courier_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['weight'];
            echo $field;
        }

        function get_chosen_courier_customer($id) {

            $db = new dbconnection();
            $sql = "select   courier.customer from courier where courier_id=:courier_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['customer'];
            echo $field;
        }

        function All_courier() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  courier_id   from courier";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_courier() {
            $con = new dbconnection();
            $sql = "select courier.courier_id from courier
                    order by courier.courier_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['courier_id'];
            return $first_rec;
        }

        function get_last_courier() {
            $con = new dbconnection();
            $sql = "select courier.courier_id from courier
                    order by courier.courier_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['courier_id'];
            return $first_rec;
        }

        function list_courier_reception($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select courier_reception.courier_reception_id,
                         courier.name as courier,  courier.weight,
                          new_trip.new_trip_id,new_trip.trip,  new_trip.entry_date,
                          Customer.national_id,
                          profile.profile_id,  profile.dob,  profile.name as fname,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence,
                        Trip.departure,  Trip.destination,  Trip.departure_time,  Trip.trp_duration,
                        account.username as User,
                        stops.stop_name as stop
                         
                        from courier_reception 
                        join courier on courier.courier_id=courier_reception.courier
                        join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                         join trip on new_trip.Trip = Trip.Trip_id 
                        join customer on customer.customer_id=courier.customer
                         join profile on Customer.profile = profile.profile_id
                         join account on account.account_id=courier_reception.User 
                         join stops on stops.Stops_id=courier_reception.stop";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>  <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><div class="parts no_shade_noBorder customer_box">
                    <table>
                        <thead>
                            <tr class="header_customer">
                                <td colspan="4"><b>CUSTOMER NAMES: <?php echo $row['fname'] . '  ' . $row['last_name']; ?></b></td>
                            </tr>
                        </thead>
                        <tr> <td class="bold_td_cust">ID:</td> <td> <?php echo $row['courier_reception_id']; ?>    </td>
                            <td class="bold_td_cust">GENDER</td> <td> <?php echo $row['gender']; ?>    </td> </tr>

                        <tr>
                            <td class="bold_td_cust">PHONE NUMBER</td>   <td><?php echo $row['telephone_number']; ?>    </td>
                            <td class="bold_td_cust">EMAIL</td>          <td>    <?php echo $row['email']; ?>    </td>
                        </tr>

                        <tr>
                            <td class="bold_td_cust">RESIDENCE</td><td> <?php echo $row['residence']; ?>    </td>
                            <td class="bold_td_cust">COURIER</td> <td class="courier_id_cols courier_reception " title="courier_reception" >  <?php echo $this->_e($row['courier']); ?>
                            </td>
                        </tr>

                        <tr>
                            <td class="bold_td_cust">ENTRY DATE</td><td> <?php echo $this->_e($row['entry_date']); ?>   </td>
                            <td class="bold_td_cust">RECEPTIONIST</td> <td> <?php echo $this->_e($row['User']); ?>   </td>
                        </tr>
                        <tr>
                            <td class="bold_td_cust">LINE</td><td>  <?php echo $this->_e($row['departure'] . ' => ' . $row['destination']); ?>  </td>
                            <td class="bold_td_cust">INITIAL STOP</td><td> <?php echo $this->_e($row['stop']); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td class="bold_td_cust">FINAL DESTINATION</td><td>  <?php echo $this->_e($row['destination']); ?>  </td>

                        </tr>
                        <tr class="change_dele_bg">
                            <td colspan="2">  <a href="#" class="courier_reception_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_reception_id']; ?>"  data-table="courier_reception">Delete</a>
                            </td>
                            <td colspan="2">
                                <a href="#" class="courier_reception_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_reception_id']; ?>" data-table="courier_reception" >Update</a>
                            </td>
                        </tr>
                    </table>
                </div>
                <?php
                $pages += 1;
            }
            ?> 
            <?php
        }

        function list_courier_reception_by_reference_number($ref) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select courier_reception.courier_reception_id,
                         courier.name as courier,  courier.weight,
                          new_trip.new_trip_id,new_trip.trip,  new_trip.entry_date,
                          Customer.national_id,
                          profile.profile_id,  profile.dob,  profile.name as fname,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence,
                        Trip.departure,  Trip.destination,  Trip.departure_time,  Trip.trp_duration,
                        account.username as User,
                        stops.stop_name as stop
                         
                        from courier_reception 
                        join courier on courier.courier_id=courier_reception.courier
                        join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                         join trip on new_trip.Trip = Trip.Trip_id 
                        join customer on customer.customer_id=courier.customer
                         join profile on Customer.profile = profile.profile_id
                         join account on account.account_id=courier_reception.User 
                         join stops on stops.Stops_id=courier_reception.stop 
                         where new_trip.reference_number=:ref";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":ref" => $ref));
            ?>  <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><div class="parts no_shade_noBorder customer_box">
                    <table>
                        <thead>
                            <tr class="header_customer">
                                <td colspan="4"><b>CUSTOMER NAMES: <?php echo $row['fname'] . '  ' . $row['last_name']; ?></b></td>
                            </tr>
                        </thead>
                        <tr> <td class="bold_td_cust">ID:</td> <td> <?php echo $row['courier_reception_id']; ?>    </td>
                            <td class="bold_td_cust">GENDER</td> <td> <?php echo $row['gender']; ?>    </td> </tr>

                        <tr>
                            <td class="bold_td_cust">PHONE NUMBER</td>   <td><?php echo $row['telephone_number']; ?>    </td>
                            <td class="bold_td_cust">EMAIL</td>          <td>    <?php echo $row['email']; ?>    </td>
                        </tr>

                        <tr>
                            <td class="bold_td_cust">RESIDENCE</td><td> <?php echo $row['residence']; ?>    </td>
                            <td class="bold_td_cust">COURIER</td> <td class="courier_id_cols courier_reception " title="courier_reception" >  <?php echo $this->_e($row['courier']); ?>
                            </td>
                        </tr>

                        <tr>
                            <td class="bold_td_cust">ENTRY DATE</td><td> <?php echo $this->_e($row['entry_date']); ?>   </td>
                            <td class="bold_td_cust">RECEPTIONIST</td> <td> <?php echo $this->_e($row['User']); ?>   </td>
                        </tr>
                        <tr>
                            <td class="bold_td_cust">LINE</td><td>  <?php echo $this->_e($row['departure'] . ' => ' . $row['destination']); ?>  </td>
                            <td class="bold_td_cust">INITIAL STOP</td><td> <?php echo $this->_e($row['stop']); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td class="bold_td_cust">FINAL DESTINATION</td><td>  <?php echo $this->_e($row['destination']); ?>  </td>

                        </tr>
                        <tr class="change_dele_bg">
                            <td colspan="2">  <a href="#" class="courier_reception_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['courier_reception_id']; ?>"  data-table="courier_reception">Delete</a>
                            </td>
                            <td colspan="2">
                                <a href="#" class="courier_reception_update_link" style="color: #000080;" data-id_update="<?php echo $row['courier_reception_id']; ?>" data-table="courier_reception" >Update</a>
                            </td>
                        </tr>
                    </table>
                </div>
                <?php
                $pages += 1;
            }
            ?> 
            <?php
        }

        function get_last_reference_number() {
            $con = new dbconnection();
            $sql = "select reference_number from new_trip order by new_trip.new_trip_id desc limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reference_number'];
            return $first_rec;
        }

        function get_reference_number_exists($ref) {
            $con = new dbconnection();
            $sql = "select reference_number from new_trip where reference_number=:ref";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":ref" => $ref));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reference_number'];
            return $first_rec;
        }

//chosen individual field
        function get_chosen_courier_reception_courier($id) {

            $db = new dbconnection();
            $sql = "select   courier_reception.courier from courier_reception where courier_reception_id=:courier_reception_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_reception_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['courier'];
            echo $field;
        }

        function get_chosen_courier_reception_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   courier_reception.entry_date from courier_reception where courier_reception_id=:courier_reception_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_reception_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_courier_reception_User($id) {

            $db = new dbconnection();
            $sql = "select   courier_reception.User from courier_reception where courier_reception_id=:courier_reception_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_reception_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_courier_reception_new_trip_id($id) {

            $db = new dbconnection();
            $sql = "select   courier_reception.new-trip_id from courier_reception where courier_reception_id=:courier_reception_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_reception_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['new-trip_id'];
            echo $field;
        }

        function get_chosen_courier_reception_stop($id) {

            $db = new dbconnection();
            $sql = "select   courier_reception.stop from courier_reception where courier_reception_id=:courier_reception_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':courier_reception_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['stop'];
            echo $field;
        }

        function All_courier_reception() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  courier_reception_id   from courier_reception";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_courier_reception() {
            $con = new dbconnection();
            $sql = "select courier_reception.courier_reception_id from courier_reception
                    order by courier_reception.courier_reception_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['courier_reception_id'];
            return $first_rec;
        }

        function get_last_courier_reception() {
            $con = new dbconnection();
            $sql = "select courier_reception.courier_reception_id from courier_reception
                    order by courier_reception.courier_reception_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['courier_reception_id'];
            return $first_rec;
        }

        function list_new_trip($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from new_trip";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> new_trip </td>
                        <td> trip </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['new_trip_id']; ?>
                        </td>
                        <td class="trip_id_cols new_trip " title="new_trip" >
                            <?php echo $this->_e($row['trip']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="new_trip_delete_link" style="color: #000080;" data-id_delete="new_trip_id"  data-table="
                               <?php echo $row['new_trip_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="new_trip_update_link" style="color: #000080;" value="
                               <?php echo $row['new_trip_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_new_trip_trip($id) {

                $db = new dbconnection();
                $sql = "select   new_trip.trip from new_trip where new_trip_id=:new_trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':new_trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['trip'];
                echo $field;
            }

            function get_chosen_new_trip_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   new_trip.entry_date from new_trip where new_trip_id=:new_trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':new_trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_new_trip_User($id) {

                $db = new dbconnection();
                $sql = "select   new_trip.User from new_trip where new_trip_id=:new_trip_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':new_trip_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_new_trip() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  new_trip_id   from new_trip";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_new_trip() {
                $con = new dbconnection();
                $sql = "select new_trip.new_trip_id from new_trip
                    order by new_trip.new_trip_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['new_trip_id'];
                return $first_rec;
            }

            function get_first_stop_by_trip($trip) {
                $con = new dbconnection();
                $sql = "select stops.stops_id from stops  
                          where stops.trip=:trip limit 1"
                        . "";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":trip" => $trip));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['stops_id'];
                return $first_rec;
            }

            function get_last_stop_by_trip($trip) {
                $con = new dbconnection();
                $sql = "select stops.stops_id from stops  
                          where stops.trip=:trip order by stops.stops_id desc  limit 1"
                        . "";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":trip" => $trip));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['stops_id'];
                return $first_rec;
            }

            function get_last_stop_by_ref($reference_no) {
                $con = new dbconnection();
                $sql = " select stops.stop_name from stops  
                            join courier_reception on stops.Stops_id=courier_reception.stop 
                         join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                           join trip on new_trip.Trip = Trip.Trip_id                        
                            where new_trip.reference_number=:reference
                            order by stops.stops_id asc  limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":reference" => $reference_no));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['stop_name'];
                return $first_rec;
            }

            function get_last_new_trip() {
                $con = new dbconnection();
                $sql = "select new_trip.new_trip_id from new_trip
                        order by new_trip.new_trip_id desc
                        limit 1 ";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['new_trip_id'];
                return $first_rec;
            }

            function get_last_new_trip_by_trip($trip) {
                $con = new dbconnection();
                $sql = "select new_trip.new_trip_id from new_trip
                        order by new_trip.new_trip_id desc
                        where new_trip.trip=:trip limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":trip" => $trip));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['new_trip_id'];
                return $first_rec;
            }

            function get_if_trip_status_by_customer($customer) {
                $con = new dbconnection();
                $sql = "select new_trip.status from courier_reception
                        join courier  on courier_reception.courier = courier.courier_id 
                        join customer on customer.Customer_id=courier.customer
                        join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                        join trip on trip.Trip_id=new_trip.trip
                        join stops on stops.trip=trip.Trip_id
                        where   customer.Customer_id=:customer";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":customer" => $customer));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['status'];
                return $first_rec;
            }

            function get_if_trip_by_customer($customer) {
                $con = new dbconnection();
                $sql = "select new_trip.trip from courier_reception
                        join courier  on courier_reception.courier = courier.courier_id 
                        join customer on customer.Customer_id=courier.customer
                        join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id 
                        where   customer.Customer_id=:customer";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":customer" => $customer));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['trip'];
                return $first_rec;
            }

            function get_stops_by_trip($trip) {//Here is to ge the stops by line (trip), to see if the package has not been delivered to the last destination
                $con = new dbconnection();
                $sql = "select count(stops.Stops_id) as stops from courier_reception
                        join courier  on courier_reception.courier = courier.courier_id 
                        join customer on customer.Customer_id=courier.customer
                        join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                        join trip on trip.Trip_id=new_trip.trip
                        join stops on stops.trip=trip.Trip_id  
                         where trip.Trip_id=:trip ";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":trip" => $trip));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['stops'];
                return $first_rec;
            }

            function get_reception_by_customer($customer) {//Here is to ge the stops by line (trip), to see if the package has not been delivered to the last destination
                $con = new dbconnection();
                $sql = "select count(courier_reception.courier_reception_id) as courier from courier_reception
                        join courier  on courier_reception.courier = courier.courier_id 
                        join customer on customer.Customer_id=courier.customer
                        join new_trip on new_trip.new_trip_id=courier_reception.new_trip_id
                        join trip on trip.Trip_id=new_trip.trip
                        where new_trip.status='on' and customer.Customer_id=:customer ";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":customer" => $customer));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['courier'];
                return $first_rec;
            }

            function get_account_by_courier_rec($profile) {//Here is to ge the stops by line (trip), to see if the package has not been delivered to the last destination
                $con = new dbconnection();
                $sql = "select "
                        . " profile.profile_id,"
                        . " courier_reception.User "
                        . " from courier_reception "
                        . " join account on account.account_id=courier_reception.User "
                        . " join profile on profile.profile_id=account.profile"
                        . " where courier_reception.courier_reception_id=:courier";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute(array(":courier" => $profile));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function get_account_category_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select account_category.account_category_id,   account_category.name from account_category";
                ?>
            <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_profile_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id,   profile.name from profile";
            ?>
            <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_image_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select image.image_id,   image.name from image";
            ?>
            <select class="textbox cbo_image"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_customer_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select customer.customer_id,profile.name, profile.last_name  from customer  "
                    . " join profile on Customer.profile = profile.profile_id ";
            ?>
            <select class="textbox cbo_customer"  name="cbo_customer"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['customer_id'] . ">" . $row['name'] . "  " . $row['last_name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_courier_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select courier.courier_id,   courier.name from courier";
            ?>
            <select class="textbox cbo_courier"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['courier_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_new_trip_id_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select new_trip.new_trip_id  from new_trip";
            ?>
            <select class="textbox cbo_new-trip_id"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['new_trip_id_id'] . ">" . $row['new_trip_id_id'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_stop_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select stop.stop_id,   stop.name from stop";
            ?>
            <select class="textbox cbo_stop"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['stop_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_trip_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select trip.trip_id  from trip";
            ?>
            <select class="textbox cbo_trip" name="cbo_trip"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['trip_id'] . ">" . $row['trip_id'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_trip_middle_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select trip.trip_id, trip.departure, trip.destination  from trip";
            ?>
            <select class="textbox cbo_trip" name="cbo_trip"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['trip_id'] . ">" . $row['departure'] . " => " . $row['destination'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_trip_wth_stop_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select distinct trip.trip_id, trip.departure, trip.destination  from trip "
                    . " join stops on stops.trip = trip.trip_id ";
            ?>
            <select class="textbox cbo_trip" name="cbo_trip"><option></option>
                    <?php
                    foreach ($db->query($sql) as $row) {
                        echo "<option value=" . $row['trip_id'] . ">" . $row['departure'] . " => " . $row['destination'] . " </option>";
                    }
                    ?>
            </select>
            <?php
        }

        function get_ref_exists($ref) {//Here is to ge the stops by line (trip), to see if the package has not been delivered to the last destination
            $con = new dbconnection();
            $sql = " ";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":courier" => $profile));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function _e($string) {
            echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        }

    }
    