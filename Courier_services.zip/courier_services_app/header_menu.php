<style>
    .web_header{
        background-color: #0790de;
        color: #fff;
        padding-left: 10%;
    }
    .menu a:first-of-type{
        padding-left: 7%;
    }
    .menu{
        border-bottom: 1px solid #0790de; 
    }
</style>

<div class="parts  full_center_two_h heit_free no_shade_noBorder margin_free web_header" id="web_header">  
    <div class="parts  no_paddin_shade_no_Border xxx_titles ">
        <div class="also_logo">

        </div>
        Courier Services
    </div>
</div>     
<div class="parts menu  full_center_two_h heit_free no_shade_noBorder">
    <a href="#">Home</a>
    <a href="#">Services</a>
    <a href="#">About</a>
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>

