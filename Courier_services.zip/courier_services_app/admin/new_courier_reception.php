<?php
    session_start();
    require_once '../web_db/multi_values.php';

    function get_profile_id() {
        $m1 = new multi_values();
        return $profile_id = trim((isset($_SESSION['table_to_update'])) && trim($_SESSION['table_to_update']) == 'courier_reception') ? $m1->get_account_by_courier_rec($_SESSION['id_upd']) : '';
    }

    //$profile_id = trim((isset($_SESSION['table_to_update'])) && trim($_SESSION['table_to_update']) == 'courier_reception') ? $m1->get_account_by_courier_rec($_SESSION['id_upd']) : '';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_courier_reception'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $courier_reception_id = $_SESSION['id_upd'];
                $courier = trim($_POST['txt_courier_id']);
                $entry_date = date("y-m-d");
                $User = $_SESSION['userid'];
                $new_trip_id = $_POST['txt_new-trip_id_id'];
                $stop = $_POST['txt_stop_id'];
                $upd_obj->update_courier_reception($courier, $entry_date, $User, $new - trip_id, $stop, $courier_reception_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $m = new multi_values();
            $trip = trim($_POST['cbo_trip']); //This is the line
            //Profile
            // <editor-fold defaultstate="collapsed" desc="-- Profile --">
            $dob = $_POST['txt_dob'];
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $gender = $_POST['txt_gender'];
            $telephone_number = $_POST['txt_telephone_number'];
            $email = $_POST['txt_email'];
            $residence = $_POST['txt_residence'];
            $national_id = $_POST['txt_national_id'];
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, 0);

            $last_profile = $m->get_last_profile();
            //Account
            //
            $obj->new_Customer($last_profile, $national_id);
// </editor-fold>

            $customer = $m->get_last_Customer();
            // <editor-fold defaultstate="collapsed" desc="--Courier --">
            $courier_name = $_POST['txt_package'];
            $weight = $_POST['txt_weight'];
            $obj->new_courier($courier_name, $weight, $customer);
// </editor-fold>
            //Reception
            // <editor-fold defaultstate="collapsed" desc="-- New Trip --">

            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];

            $rand_ref = filter_input(INPUT_POST, 'txt_reference_no');

            //check if reference number is not taken

            $obj->new_new_trip($trip, $entry_date, $User, 'on', $rand_ref);
            // </editor-fold>
            $last_trip = $m->get_last_new_trip();
            $courier = $m->get_last_courier();

            // <editor-fold defaultstate="collapsed" desc=" --  Reception --">
            $stop = $m->get_first_stop_by_trip($trip);
            $obj->new_courier_reception($courier, $entry_date, $User, $last_trip, $stop);

// </editor-fold>
            //Get the reference number
            $last_ref = $m->get_last_reference_number();
            ?><script>
                $('.abs_full').fadeIn(function () {
                    //                    $('.after_saving').fadeIn(20);
                });
                alert('Saved successfully');
            </script>
            <div class="after_saving">
                <?php // echo $last_ref; ?>
            </div>
            <?php
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            courier reception
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .after_saving{
                position: absolute;
                color: #fff;
                z-index: 12;
                width: 30%;
                left: 35%;
                top: 10%;

                background-color: #2c88c5;
                padding: 20px;
            }
            .customer_box{
                width: 45%;
            }
        </style>
    </head>
    <body>
        <form action="new_courier_reception.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_courier_id"   name="txt_courier_id"/>
            <input type="hidden" id="txt_new-trip_id_id"   name="txt_new-trip_id_id"/>
            <input type="hidden" id="txt_stop_id"   name="txt_stop_id"/>
            <input type="hidden" id="txt_reference_no"   name="txt_reference_no"/>
            <?php include 'admin_header.php'; ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>


            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>   
            <!--End dialog-->
            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                courier_reception saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts no_paddin_shade_no_Border">
                    <table class="new_data_table">
                        <tr>
                            <td colspan="2">
                                <div class="parts eighty_centered new_data_title">  Customer personal Information  </div>
                            </td>
                        </tr>
                        <tr><td><label for="txt_dob"> Date Of Birth</label></td><td> <input type="text" autocomplete="off"    name="txt_dob" required id="txt_dob"  class="textbox date" value="<?php echo trim(chosen_dob_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_name">Name </label></td><td> <input type="text"     name="txt_name" required id="txt_name" class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_last_name"> Last name</label></td><td> <input type="text"     name="txt_last_name" required id="txt_last_name" class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_gender">Gender</label></td><td> 
                                <select class="textbox" name="txt_gender">
                                    <option></option>
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                            </td></tr>
                        <tr><td><label for="txt_telephone_number"> Telephone</label></td><td> <input type="text"     name="txt_telephone_number" required id="txt_telephone_number" class="textbox" value="<?php echo trim(chosen_telephone_number_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_email"> Email</label></td><td> <input type="text"     name="txt_email" required id="txt_email" class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   />  </td></tr>
                    </table>
                </div>
                <div class="parts no_paddin_shade_no_Border  ">
                    <table class="new_data_table">
                        <tr>
                            <td colspan="2">
                                <div class="parts eighty_centered new_data_title">  Customer Belongings Information  </div>
                            </td>
                        </tr>       <tr><td><label for="txt_residence"> Residence</label></td><td> <input type="text"     name="txt_residence" required id="txt_residence" class="textbox" value="<?php echo trim(chosen_residence_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_national_id">National ID </label></td><td> <input type="text"     name="txt_national_id" required id="txt_national_id" class="textbox" value="<?php echo trim(chosen_national_id_upd()); ?>"   />  </td></tr>

                        <tr><td><label for="txt_name">Package <br/>description </label></td><td> <input type="text"     name="txt_package" required id="txt_name" class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                        <tr><td><label for="txt_weight">Weight  </label></td><td> <input type="text"     name="txt_weight" required id="txt_weight" class="textbox" value="<?php echo trim(chosen_weight_upd()); ?>"   />  </td></tr>
                        <tr><td class="new_data_tb_frst_cols">Line </td><td> <?php get_trip_combo(); ?>  </td></tr>
                        <tr>
                            <td></td>
                            <td> <input type="submit" class="confirm_buttons" name="send_courier_reception" value="Save"/>
                                <div class="parts push_right no_paddin_shade_no_Border margin_free">
                                    <input type="submit" name="cancel_button"   value="cancel" class="red_button cancel_button margin_free send_courier_reception" style="">
                                </div>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="parts ninety_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">courier_reception List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_courier_reception();
                    $obj->list_courier_reception($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/key_gen.js" type="text/javascript"></script> 
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>

        <script>
                $(document).ready(function () {
                    $('.date').datepicker({
                        dateFormat: 'yy-mm-dd'
                    });
                });
        </script>
        <div class="parts ninety_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {
                var courier = '<?php echo chosen_courier_upd(); ?>';
                $('.cbo_courier').val(courier);
                $('#txt_courier_id').val(courier);
                var new_trip_id = '<?php echo chosen_new_trip_id_upd(); ?>';
                $('.cbo_new-trip_id').val(new_trip_id);
                $('#txt_new-trip_id_id').val(new_trip_id);
                var stop = '<?php echo chosen_stop_upd(); ?>';
                $('.cbo_stop').val(stop);
                $('#txt_stop_id').val(stop);
            }
            //Addon
            $('.send_courier_reception').click(function () {
                var cont = 'c';
                $.post('new_courier_reception.php', {send_courier_reception: send_courier_reception}, function (data) {
                    alert('data');
                }).complete(function () {

                });
                return false;
            });
        </script>
    </body>
</hmtl>
<?php

    function chosen_courier_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = $_SESSION['id_upd'];
                $courier = new multi_values();
                return $courier->get_chosen_courier_reception_courier($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_courier_reception_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_courier_reception_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_new_trip_id_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = $_SESSION['id_upd'];
                $new_trip_id = new multi_values();
                return $new_trip_id->get_chosen_courier_reception_new_trip_id($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_stop_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = $_SESSION['id_upd'];
                $stop = new multi_values();
                return $stop->get_chosen_courier_reception_stop($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function get_courier_combo() {
        $obj = new multi_values();
        $obj->get_courier_in_combo();
    }

    function get_new_trip_id_combo() {
        $obj = new multi_values();
        $obj->get_new_trip_id_in_combo();
    }

    function get_stop_combo() {
        $obj = new multi_values();
        $obj->get_stop_in_combo();
    }

    function get_trip_combo() {
        $obj = new multi_values();
        $obj->get_trip_wth_stop_in_combo();
    }

    // <editor-fold defaultstate="collapsed" desc="-- profile --">
    //Staff (Profile unit)
    function chosen_dob_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $dob = new multi_values();
                return $dob->get_chosen_profile_dob($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $name = new multi_values();
                return $name->get_chosen_profile_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_last_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $last_name = new multi_values();
                return $last_name->get_chosen_profile_last_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_gender_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $gender = new multi_values();
                return $gender->get_chosen_profile_gender($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_telephone_number_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $telephone_number = new multi_values();
                return $telephone_number->get_chosen_profile_telephone_number($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_email_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $email = new multi_values();
                return $email->get_chosen_profile_email($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_residence_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $residence = new multi_values();
                return $residence->get_chosen_profile_residence($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="-- Courier --">


    function chosen_weight_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier') {
                $id = $_SESSION['id_upd'];
                $weight = new multi_values();
                return $weight->get_chosen_courier_weight($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_customer_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier') {
                $id = $_SESSION['id_upd'];
                $customer = new multi_values();
                return $customer->get_chosen_courier_customer($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function get_customer_combo() {
        $obj = new multi_values();
        $obj->get_customer_in_combo();
    }

// </editor-fold>

    function chosen_national_id_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'courier_reception') {
                $id = get_profile_id();
                $national_id = new multi_values();
                return $national_id->get_chosen_Customer_national_id($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    