<?php

    session_start();

    if (isset($_POST['cbo_account_category'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_image'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_trip'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_trip_id_by_trip_name($_POST['cbo_trip']);
        return $id;
    }
    if (isset($_POST['cbo_customer'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_customer_id_by_customer_name($_POST['cbo_customer']);
        return $id;
    }
    if (isset($_POST['cbo_courier'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_courier_id_by_courier_name($_POST['cbo_courier']);
        return $id;
    }
    if (isset($_POST['cbo_new-trip_id'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_new - trip_id_id_by_new - trip_id_name($_POST['cbo_new-trip_id']);
        return $id;
    }
    if (isset($_POST['cbo_stop'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_stop_id_by_stop_name($_POST['cbo_stop']);
        return $id;
    }
    if (isset($_POST['cbo_trip'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_trip_id_by_trip_name($_POST['cbo_trip']);
        return $id;
    }

    if (isset($_POST['table_to_update'])) {
        $id_upd = $_POST['id_update'];
        $table_upd = $_POST['table_to_update'];
        $pref = 'upd_';
        $sufx = $table_upd;
        $_SESSION['table_to_update'] = $table_upd;
        $_SESSION['id_upd'] = $id_upd;
        echo $_SESSION['id_upd'];
    }

    if (filter_has_var(INPUT_POST, 'unuset_update')) {
        unset($_SESSION['table_to_update']);
    }
//The Delete from account
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account($id);
    }
//The Delete from account_category
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account_category($id);
    }
//The Delete from profile
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_profile($id);
    }
//The Delete from image
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_image($id);
    }
//The Delete from Trip
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'Trip') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_Trip($id);
    }
//The Delete from Customer
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'Customer') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_Customer($id);
    }
//The Delete from Stops
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'Stops') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_Stops($id);
    }
//The Delete from courier
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'courier') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_courier($id);
    }
//The Delete from courier_reception
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'courier_reception') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_courier_reception($id);
    }
//The Delete from new_trip
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'new_trip') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_new_trip($id);
    }
    if (isset($_POST['pagination_n'])) {
        $_SESSION['pagination_n'] = $_POST['pagination_n'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['paginated_page'];
    }
    if (isset($_POST['page_no_iteml'])) {
        unset($_SESSION['pagination_n']);
        $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['page_no_iteml'];
    }

    //Addon

    if (filter_has_var(INPUT_POST, 'ref_no_found')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $ref = filter_input(INPUT_POST, 'ref_no_found');
        echo $obj->get_reference_number_exists($ref);
    }
    if (filter_has_var(INPUT_POST, 'trip_by_ref_no')) {
        $trip_by_ref_no = filter_input(INPUT_POST, 'trip_by_ref_no');
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        echo 'Current location: ' . trim($obj->get_last_stop_by_ref($trip_by_ref_no)) . '<br />';
        echo '<div class="">' . $obj->list_courier_reception_by_reference_number($trip_by_ref_no);
    }