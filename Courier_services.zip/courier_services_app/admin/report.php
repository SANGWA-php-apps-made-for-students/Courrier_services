<?php
    session_start();
    require_once '../web_db/multi_values.php';
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            Trip</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            #loading_gif{
                background-image: url('../web_images/continuous.gif');
                background-repeat: no-repeat;
            }
        </style>
    </head>
    <body>

        <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
        <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

        <?php
            include 'admin_header.php';
        ?>

        <!--Start dialog's-->
        <div class="parts abs_full  off"> </div>
        <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
            <div class="parts full_center_two_h heit_free margin_free skin">
                Do you really want to delete this record?
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
            </div>
        </div>

        <!--End dialog-->

        <div class="parts eighty_centered off saved_dialog">
            Trip saved successfully!
        </div>
        <div class="parts eighty_centered new_data_box  ">
            <div class="parts eighty_centered new_data_title x_titles"> Report  </div>
            <div class="parts eighty_centered new_data_title"> Search by tracking number  </div>
            <table class="new_data_table">
                <tr>
                    <td>Enter a tracking number:</td><td>
                        <input type="text" class="textbox" id="txt_tracking_number" name="txt_tracking_number"  />
                    </td>
                    <td>
                        <input type="submit" name="search" value="Search" class="confirm_buttons  margin_free" id="btn_search" style="margin-top: 0px;"/>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div class="parts no_paddin_shade_no_Border full_center_two_h heit_free off" id="loading_gif">

                        </div>
                        <div class="parts no_paddin_shade_no_Border" id="data_res"></div>
                    </td>
                </tr>
            </table>

        </div>

        <div class="parts eighty_centered datalist_box" >
            <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">Lines List</div>
            <?php
                $obj = new multi_values();
                $first = $obj->get_first_Trip();
                $obj->list_Trip($first);
            ?>
        </div>  

        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {

                $('#btn_search').click(function () {

                    var trip_by_ref_no = $('#txt_tracking_number').val();
                    var res = '';
                    $('#loading_gif').show(10);
                    $.post('handler.php', {trip_by_ref_no: trip_by_ref_no}, function (data) {
                        res = data;

                    }).complete(function () {
                        $('#loading_gif').hide(100, function () {
                            $('#data_res').html(res);
                        });
                    });
                    return false;
                });
            });
        </script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {
            }
        </script>
    </body>
</hmtl>
<?php

    function chosen_departure_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'Trip') {
                $id = $_SESSION['id_upd'];
                $departure = new multi_values();
                return $departure->get_chosen_Trip_departure($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_destination_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'Trip') {
                $id = $_SESSION['id_upd'];
                $destination = new multi_values();
                return $destination->get_chosen_Trip_destination($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_departure_time_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'Trip') {
                $id = $_SESSION['id_upd'];
                $departure_time = new multi_values();
                return $departure_time->get_chosen_Trip_departure_time($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_trp_duration_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'Trip') {
                $id = $_SESSION['id_upd'];
                $trp_duration = new multi_values();
                return $trp_duration->get_chosen_Trip_trp_duration($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_comments_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'Trip') {
                $id = $_SESSION['id_upd'];
                $comments = new multi_values();
                return $comments->get_chosen_Trip_comments($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    