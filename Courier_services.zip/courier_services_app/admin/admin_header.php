<?php
//    if (!isset($_SESSION)) {
//        session_start();
//    }
//    if ($_SESSION['cat'] == 'admin') {
        admin();
//    } else if ($_SESSION['cat'] == 'cashier') {
//        cashier();
//    }
?>
<style>
    .web_header{
        background-color: #0790de;
        color: #fff;
        padding-left: 10%;
    }
    .menu a:first-of-type{
        padding-left: 7%;
    }
    .menu{
        border-bottom: 1px solid #0790de; 
    }
</style>



<?php

    function admin() {
        ?>
        <div class = "parts  full_center_two_h heit_free no_shade_noBorder margin_free web_header" id = "web_header">
            <div class = "parts  no_paddin_shade_no_Border xxx_titles ">
                <div class = "also_logo">

                </div>
                Courier Services
            </div>
        </div>
        <div class = "parts menu  full_center_two_h heit_free no_shade_noBorder">
            <a href = "new_account.php">Staff</a>
            <a href = "new_Trip.php">Lines</a>
            <a href = "new_Stops.php">Stops</a>
            <a href = "new_courier_reception.php">New Trip</a>
            <a href = "new_courier.php">Reception</a>
            <a href = "report.php">Report</a>

            <div class = "parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href = "../logout.php"><?php echo'(' . $_SESSION['cat'] . ')' ?>  Logout</a>
            </div>
        </div><?php
    }

    function cashier() {
        ?>
        <div class = "parts  full_center_two_h heit_free no_shade_noBorder margin_free web_header" id = "web_header">
            <div class = "parts  no_paddin_shade_no_Border xxx_titles ">
                <div class = "also_logo">
                    
                </div>
                Courier Services
            </div>
        </div>
        <div class = "parts menu  full_center_two_h heit_free no_shade_noBorder">

            <a href = "new_courier_reception.php">New Trip</a>
            <a href = "new_courier.php">Reception</a>
            <a href = "report.php">Report</a>
            <div class = "parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href = "../logout.php"><?php echo'(' . $_SESSION['cat'] . ')' ?>  Logout</a>
            </div>
        </div>    
        <?php
    }
?>



