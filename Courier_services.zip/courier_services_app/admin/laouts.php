<?php

    /**
     * Description of laouts
     *
     * Done by SANGWA on  Feb 2, 2019
     */
    class laouts {

        function get_cancel_btn() {

            return '';
        }

    }
    