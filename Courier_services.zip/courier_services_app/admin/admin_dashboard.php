<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .admin_bg{
                background-image: url('../web_images/delivery.PNG');
                width: 650px;
                height: 400px;
                background-repeat: no-repeat;
            }
        </style>
    </head>
    <body>
        <?php
            require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered">
            <div class="parts admin_bg no_paddin_shade_no_Border ">

            </div>
        </div>
    </body>
</html>
